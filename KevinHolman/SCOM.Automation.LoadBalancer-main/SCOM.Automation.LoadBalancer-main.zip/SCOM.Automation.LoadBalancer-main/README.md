# SCOM.Automation.LoadBalancer

## [Download Here][Download]

[Download]: https://github.com/thekevinholman/SCOM.Automation.LoadBalancer/archive/refs/heads/main.zip

### SCOM Agent Load Balancing Management Pack for Management Servers and Gateways

https://kevinholman.com/2021/09/07/automating-agent-load-balancing-for-management-servers-and-gateways/

Version History:
* 1.0.0.3  (09-07-2021)
	* Initial Release
